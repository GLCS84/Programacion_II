﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hola Mundo!");

///////////////////////////////////////////////

const int Meses = 12; //El error CS0219 se da porque se declara una constante pero aún no se ha usado, y el compilador actúa como un asistente que busca que el código sea limpio y eficiente
Console.WriteLine("El año tiene " + Meses + " meses."); //se agrega línea 7 para eliminar error

//////////////////////////////////////////////

int años = 27;
Console.WriteLine("Ella tiene " + años + " años.");

//////////////////////////////////////////////

using System;
class Programa
{
    public void Mostrar() // Error CS0106 se da por que el modificador public debe estar dentro de una clase
    { //inicio del alcance del método
      //variable con alcance a nivel de método
        int i = 0;
        for (i = 0; i < 4; i++) {
            Console.WriteLine(i);// accediendo a la variable de método
        }
        // j es variable a nivel del bloque for j
        for (int j = 0; j < 5; j++) {
            Console.WriteLine(j);// accediendo a la variable a nivel del bloque
        }
        Console.WriteLine(i);// genera un error dado que j está definida en el for j           
    } // fin del alcance del método
 // Error CS1529 se da porque se declara una función o método dentro de otra función pero no se llama para ejecutarse
    static void Main(string[] args)
    {
        Programa p = new Programa(); // crea instancia para llamar al método
        p.Mostrar();
    }
}

//////////////////////////////////////////////

public void Mostrar()
  { //inicio del alcance del método
    //variable con alcance a nivel del método
      int valor = 77;

      // acceso a la variable
      Console.WriteLine(valor);
  }// fin del alcance del método

//////////////////////////////////////////////

int global = 1000;
public void Mostrar()
{ //inicio del alcancel del método
  
  //variable con alcance a nivel de método
    int valor = 77;

    // acceso a la variable
    Console.WriteLine(valor);
    Console.WriteLine(global);
} // fin del alcance del método

//////////////////////////////////////////////

int valor = Int32.Parse("10");
Console.WriteLine(valor);

//////////////////////////////////////////////


